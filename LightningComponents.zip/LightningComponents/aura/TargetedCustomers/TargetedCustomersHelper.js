({
	    doInit: function(component, event, helper) {
        //helper.initData(component, event, helper);
        helper.getTargetedCustomers(component, event, helper);
      
    },
    
    getTargetedCustomers: function(component, event, helper) {
        var action = component.get('c.getInteractionTargetedCustomers');
        action.setParams({
            interactionId : component.get("v.interactionId") 
        });
 		action.setCallback(this, function(response) {
            if(response.getState()==='SUCCESS'){
                var returnValue = response.getReturnValue();
                if($A.util.isUndefinedOrNull(returnValue)){
                    component.set('v.hasTargetCustomers',true);
                }
                else{
                    component.set("v.TargetedCustomers",returnValue);
                    component.set("v.numberOfParticipants",returnValue.length);
                   // console.log(Json.stringfy(returnValue));
                }
            }
			else if (state === "ERROR") {
                $A.get("e.force:showToast").setParams({
				"title": "Failure!",
				"type":"error",
				"message": "There is an issue.Please Contact Admin"
				}).fire();
            }
            //alert(response.getReturnValue());
        });
      $A.enqueueAction(action);


        //ert(component.get("v.interactionId"));
    }
})