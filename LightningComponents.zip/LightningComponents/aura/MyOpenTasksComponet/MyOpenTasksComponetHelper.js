({
    openNewTask : function(component, event) {
        $A.get("e.force:navigateToURL").setParams({
            "url": "/00T/e"
        }).fire();
    }
})