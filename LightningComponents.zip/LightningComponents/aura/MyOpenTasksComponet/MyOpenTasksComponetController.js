({
    gotoTaskCreatePage : function (component, event, helper) {
        helper.openNewTask(component, event);
        
    },
   
})