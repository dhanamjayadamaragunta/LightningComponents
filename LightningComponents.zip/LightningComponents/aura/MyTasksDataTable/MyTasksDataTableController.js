({
    handleUnResolvedItesm: function (component, event, helper) {
        $A.get("e.force:navigateToURL").setParams({
            "url": "/6AC?src=8"
        }).fire();
    },
    handleValueChange : function (component, event, helper) {
       helper.getTaskRecords(component, event);
    },
    init : function (component, event, helper) {
        //var timezone = $A.get("$Locale.timezone");
        //var mydate =Date.valueOf(new Date().toLocaleString("en-US", {timeZone: timezone}));
        //component.set('v.todayDate',)
        ////console.log('timezone'+mydate);
        //var d = new Date();
        //console.log(d+'--->');
        //component.set("v.todayDate",mydate);component.set("v.todayDate1",d);
       helper.handleOnload(component, event);
    },
     init1 : function (component, event, helper) {
        //var timezone = $A.get("$Locale.timezone");
        //var mydate =Date.valueOf(new Date().toLocaleString("en-US", {timeZone: timezone}));
        //component.set('v.todayDate',)
        ////console.log('timezone'+mydate);
        //var d = new Date();
        //console.log(d+'--->');
        //component.set("v.todayDate",mydate);component.set("v.todayDate1",d);
       helper.handleOnload(component, event);
    },
     /*handleRowAction: function (cmp, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');
        switch (action.name) {
            case 'view_details':
                helper.viewTask(row);
                break;
            case 'edit_status':
                //helper.editRowStatus(cmp, row, action);
                break;
            default:
                //helper.showRowDetails(row);
                alert('alert');
                break;
        }
    },*/
    handleClick : function(component,event,helper) {
        helper.navigateToTaskDetails(component,event);
        
        
    }
})