({
    getTaskRecords : function(component, event) {
        if(event.getParam("oldValue") != event.getParam("value")){
            var action=component.get("c.getTasks");
            action.setParams({
                tasksFilter: event.getParam("value")
            });
            $A.enqueueAction(action);
            action.setCallback(this, function(response) {
                var state = response.getState();
                if(state === 'SUCCESS') {
                    var returnValue = response.getReturnValue();
                    if(returnValue==''){
                        component.set("v.FilteredTasks",null);
                        component.set("v.Message",'You have no open tasks scheduled for this period.');
                    }
                    else{
                        component.set("v.Message",'');
                        component.set("v.FilteredTasks",returnValue);
                    }
                }
                
            });
        }
    },
    handleOnload : function(component, event) {
        var action=component.get("c.getSystemDate");
         $A.enqueueAction(action);
        action.setCallback(this, function(response) {
                var state = response.getState();
             if(state === 'SUCCESS') {
                 component.set('v.todayDate',response.getReturnValue());
             }
        });
       /* component.set('v.columns', [
            {label: 'View', type: 'button', initialWidth: 135, typeAttributes: { label: 'Close Task', name: 'view_details', iconName:'utility:close',title: 'Click to View Details'}},
           // {label: 'Id', fieldName: 'Id', type: 'Id'},
            {label: 'Date', fieldName: 'ActivityDate', type: 'date'},
            {label: 'Status', fieldName: 'Status', type: 'text'},
            {label: 'Subject', fieldName: 'Subject', type: 'text'},
            {label: 'Name', fieldName: 'Who', type: 'text'},
            {label: 'Related To', fieldName: 'What', type: 'text'},
            {label: 'Account', fieldName: 'AccountId', type: 'text'}
        ]);*/
    },
   /* viewTask :function(row) {
          $A.get("e.force:navigateToURL").setParams({
            "url": "/"+ row.Id+"/e"
        }).fire();
    },*/
    navigateToTaskDetails : function(component,event){
        var recId =event.getSource().get("v.value");
        if(!$A.util.isUndefinedOrNull(recId)){
            $A.get("e.force:navigateToURL").setParams({
            "url": "/"+ recId+"/e"
        }).fire();
        }
    
}
})